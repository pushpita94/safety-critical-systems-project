package de.frauas.predictivemaintenance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PredictiveMaintenanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
