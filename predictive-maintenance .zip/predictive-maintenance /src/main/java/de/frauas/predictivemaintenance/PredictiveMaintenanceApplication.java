package de.frauas.predictivemaintenance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PredictiveMaintenanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PredictiveMaintenanceApplication.class, args);
	}

}
